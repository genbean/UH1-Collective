%TF.GenerationSoftware,KiCad,Pcbnew,9.0.3*%
%TF.CreationDate,2026-11-14T23:54:09-06:00*%
%TF.ProjectId,AS5600_Rev1.0,41533536-3030-45f5-9265-76312e302e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3) date 2026-11-14 23:54:09*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.400000*%
%ADD11RoundRect,0.250000X0.650000X-0.325000X0.650000X0.325000X-0.650000X0.325000X-0.650000X-0.325000X0*%
%ADD12RoundRect,0.250000X-0.325000X-0.650000X0.325000X-0.650000X0.325000X0.650000X-0.325000X0.650000X0*%
%ADD13RoundRect,0.150000X-0.825000X-0.150000X0.825000X-0.150000X0.825000X0.150000X-0.825000X0.150000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,H4*%
X119748000Y-119621000D03*
%TD*%
D11*
%TO.C,C2*%
X106420000Y-113935000D03*
X106420000Y-110985000D03*
%TD*%
D12*
%TO.C,C1*%
X109145000Y-106620000D03*
X112095000Y-106620000D03*
%TD*%
D10*
%TO.C,H3*%
X119748000Y-103619000D03*
%TD*%
%TO.C,H2*%
X103492000Y-119621000D03*
%TD*%
D13*
%TO.C,U1*%
X109145000Y-109715000D03*
X109145000Y-110985000D03*
X109145000Y-112255000D03*
X109145000Y-113525000D03*
X114095000Y-113525000D03*
X114095000Y-112255000D03*
X114095000Y-110985000D03*
X114095000Y-109715000D03*
%TD*%
D10*
%TO.C,H1*%
X103492000Y-103619000D03*
%TD*%
M02*
